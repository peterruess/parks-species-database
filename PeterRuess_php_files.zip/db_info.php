<?php


$db_server = "warehouse";
$db_name = "pcr241_db1";
$db_pwd = "pc11";
$db_user = "pcr241";






?>